function Redirect(productId){
    window.location.href = "detail.php?id=" + productId;
}