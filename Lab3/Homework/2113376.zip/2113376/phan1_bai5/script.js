function UpdateResult(value){
    document.getElementById("result").value += value;
}
function ClearScreen(){
    document.getElementById("result").value = "";
}